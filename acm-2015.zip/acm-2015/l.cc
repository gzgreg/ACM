//team 562, D2UBC^
#include <bits/stdc++.h>

using namespace std;

#define endl '\n'

int main () {
	ios::sync_with_stdio(0);
	int n,w; cin >> n >> w;
	int lastSafe[n];
	double p[n];
	int v[n];
	int lsLast = 0;
	double netMult[n];
	double netMultCurr = 1;
	for (int i=0; i<n; i++) {
		string s; cin >> s; cin >> p[i] >> v[i];
		lastSafe[i] = lsLast;
		netMultCurr *= p[i]; netMult[i] = netMultCurr;
		if(s == "safe"){
			lsLast = v[i];
		}
		
	}
	double maxVal = 0;
	for(int i = 0; i < n; i++){
		double odds = 1;
		double val = 0;
		for(int j = 0; j <= i; j++){
			double currMult = j-1 < 0 ? 1 : netMult[j - 1];
			currMult *= (1-p[j]);
			val += currMult * log(1.0 + (double) lastSafe[j] / w);
		}
		val += netMult[i] * log(1.0 + (double)v[i] / w);
		if(val > maxVal) maxVal = val;
	}
	
	double val = 500000, diff = 250000;
	while(diff > 1e-6){
		if(log(1.0+(double)val / w) > maxVal){
			val -= diff;
		} else {
			val += diff;
		}
		diff /= 2;
	}
	cout << "$" << fixed << setprecision(2) << val << endl;
	return 0;
}
