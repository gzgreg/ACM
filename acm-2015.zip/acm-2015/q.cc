//team 562, D2UBC^
#include <bits/stdc++.h>

using namespace std;

#define endl '\n'

int main () {
	int n; cin >> n;
	vector<int> vals;
	for(int i = 0; i < n; i++){
		int c; cin >> c;
		vals.push_back(c);
	}
	sort(vals.begin(), vals.end());
	int max = 2000000;
	for(int i = 0; i < n/2; i++){
		if(vals[i]+vals[n - i - 1] < max) max = vals[i]+vals[n - i - 1];
	}
	cout << max <<endl;
	return 0;
}
