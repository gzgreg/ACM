//team 562, D2UBC^
#include <bits/stdc++.h>

using namespace std;

#define endl '\n'

int main () {
	int n,h; cin >> n >> h;
	int maxS = 1;
	int minB = h;
	for(int i=0; i<n; i++) {
		int f; cin >> f;
		string s; cin >> s;
		if (s == "SAFE" && maxS < f) {
			maxS = f;
		}
		if (s == "BROKEN" &&  minB > f) minB = f;
	}
	cout << min(maxS+1,minB) << " " << max(minB-1,maxS) << endl;
	return 0;
}
