//team 562, D2UBC^
#include <bits/stdc++.h>

using namespace std;

#define endl '\n'

int main () {
	int m, n; cin >> m >> n;
	int grid[m][n];
	bool seen[m][n];
	for(int i = 0; i < m; i++){
		string s; cin >> s;
		for(int j = 0; j < n; j++){
			grid[i][j] = s[j] -'0';
			seen[i][j] = false;
		}
	}
	queue<pair<pair<int, int>, int> > bfsq;
	bfsq.push(make_pair(make_pair(0, 0), 0));
	bool check = false;
	while(!bfsq.empty()){
		pair<pair<int,int>, int> curr = bfsq.front();
		bfsq.pop();
		if(curr.first.first == m-1 && curr.first.second == n-1){
			cout << curr.second << endl;
			check = true;
			break;
		}
		if(!seen[curr.first.first][curr.first.second]){
			int val = grid[curr.first.first][curr.first.second];
			int x = curr.first.first; int y = curr.first.second;
			seen[x][y] = true;
			if(x-val >= 0){
				bfsq.push(make_pair(make_pair(x - val, y), curr.second + 1));
			}
			if(y + val < n){
				bfsq.push({{x, y+val}, curr.second + 1});
			}
			if(y-val >= 0){
				bfsq.push({{x, y-val}, curr.second + 1});
			}
			if(x+val < m){
				bfsq.push({{x+val, y}, curr.second + 1});
			}
		}
	}
	if(!check){
		cout << "IMPOSSIBLE" << endl;
		
	}
	return 0;
}
