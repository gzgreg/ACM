test = int(raw_input())
