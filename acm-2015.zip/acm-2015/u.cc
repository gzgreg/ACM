//team 562, D2UBC^
#include <bits/stdc++.h>

using namespace std;

#define endl '\n'

int main () {
	int w, h, b; cin >> w >> h >> b;
	long long grid[h][w];
	
	for(int i = 0; i < h; i++){
		for(int j = 0; j < w; j++){
			cin >> grid[i][j];
			grid[i][j] *= pow(9, b);
		}
	}
	for(int m = 0; m < b; m++){
		long long copy[h][w];
		for(int i = 0; i < h; i++){
			for(int j = 0; j < w; j++){
				long long sum = 0;
				for(int k = i-1; k <= i+1; k++){
					int y = k;
					if(y < 0) y = h-1;
					if(y >= h) y = 0;
					
					for(int l = j-1; l <= j+1; l++){
						int x = l;
						if(x < 0) x = w-1;
						if(x >= w) x = 0;
						sum += grid[y][x];
					}
				}
				copy[i][j] = sum / 9;
			}
		}
		for(int i = 0; i < h; i++){
			for(int j = 0; j < w; j++){
				grid[i][j] = copy[i][j];
			}
		}
	}
	set<long long> found;
	for(int i = 0; i < h; i++){
		for(int j = 0; j < w; j++){
			found.insert(grid[i][j]);
		}
	}
	cout << found.size() << endl;
	return 0;
}
