



#team 562 D2UBC^
s= list(raw_input())
l= len(s)

d = {}
for i in xrange(l):
	if (s[i] in d):
		d[s[i]] = d[s[i]] +1
		
	else:
		d[s[i]] = 1
value = []
for k,v in d.iteritems():
	value.append(v)
value.sort()
value.reverse()	 		
		
if (len(d) <=2):
	print 0
else:
	print int(sum(value[2:]))			
			




















