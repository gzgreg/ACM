#include <bits/stdc++.h>

using namespace std;

#define endl '\n'

int main () {
	vector<pair<string,long double> > ops;
	int n; cin >> n;
	for (int i=0; i<n; i++) {
		string s; cin >> s;
		long double num; cin >> num;
		ops.push_back({s,num});
	}
	
	int fail = 0;
	for (int i=1; i<=100; i++) {
		long double curr = i;
		for (int j=0; j<ops.size(); j++) {	
			pair<string,int> op = ops[j];
			if (op.first == "ADD") curr += op.second;
			if (op.first == "SUBTRACT") curr -= op.second;
			if (op.first == "MULTIPLY") curr *= op.second;
			if (op.first == "DIVIDE") curr/= op.second;
			if (curr < 0 || curr - floor(curr) > 1e-13) {
				fail++;
				break;
			}
		}
		
	}
	cout << fail << endl;
	return 0;
}
