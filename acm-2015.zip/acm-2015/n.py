n,k = [int(x) for x in raw_input().split()]
db = {}
ds = {}
s = []
b = []
db[k] = 'BROKEN'
ds[1] 'SAFE'
for i in xrange(n):
	f,status = raw_input().split()
	if (str(status) == 'SAFE'):
		ds[int(f)] = 'SAFE'
		s.append(int(f))
	else:
		db[int(f)]= 'BROKEN'
		b.append(int(f))
		
# first bound
low = 0
if (len(ds) >0):
	low = max(max(s) + 1)
else:
	low = 	
	
# second bound
safe = max(s)
if (safe+1 not i)			
		
	

	
