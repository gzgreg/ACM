//team 562, D2UBC^
#include <bits/stdc++.h>

using namespace std;

#define endl '\n'

int main () {
	int n; cin >> n;
	int x[1000], y[1000], r[1000];
	for(int i = 0; i < n; i++){
		cin >> x[i] >> y[i] >> r[i];
	}
	
	vector<vector<int> > list;
	for(int i = 0; i < n; i++){
		vector<int> empty;
		list.push_back(empty);
	}
	for(int i = 0; i < n; i++){
		for(int j = 0; j < i; j++){
			if((x[i] - x[j])*(x[i] - x[j]) + (y[i] - y[j])*(y[i] - y[j]) == (r[i] + r[j])*(r[i] + r[j])){
				list[i].push_back(j);
				list[j].push_back(i);
			}
		}
	}
	long long numer[1000]; numer[0] = 1;
	long long denom[1000]; denom[0] = 1;
	set<int> visited;
	queue<int> bfsq;
	bfsq.push(0);
	while(!bfsq.empty()){
		int curr = bfsq.front();
		bfsq.pop();
		visited.insert(curr);
		for(int i = 0; i < list[curr].size(); i++){
			int other = list[curr][i];
			if(visited.find(other) != visited.end()){
				long long numerator = -numer[curr] * r[curr];
				long long denominator = denom[curr] * r[other];
				if(abs((double) numerator / denominator - (double) numer[other] / denom[other]) >= 1e-10){
					cout << "The input gear cannot move." << endl;
					return 0;
				}
			} else {
				numer[other] = -numer[curr] * r[curr];
				denom[other] = denom[curr] * r[other];
				long long gcd = __gcd(numer[other], denom[other]);
				numer[other] /= gcd;
				denom[other] /= gcd;
				bfsq.push(other);
			}
		}
	}
	if(visited.find(n-1) == visited.end()){
		cout << "The input gear is not connected to the output gear." << endl;
	} else {
		long long gcd = __gcd(numer[n-1], denom[n-1]);
		cout << numer[n-1] / gcd << ":" << denom[n-1] / gcd << endl;
	}
	return 0;
}
