#include <bits/stdc++.h>

using namespace std;

#define endl '\n'

int main () {
	int n; cin >> n;
	set<pair<string,string>> names;
	while(n--) {
		string s1, s2; cin >> s1 >> s2;
		names.insert({s2,s1});
	}
	for (auto pss : names) {
		cout << pss.second << " " << pss.first << endl;
	}
	return 0;
}
