#include <bits/stdc++.h>

using namespace std;

#define endl '\n'

int main () {
	vector<int> v1;
	vector<int> v2;
	
	for (int i=0; i<3; i++) {
		int a; cin >> a;
		v1.push_back(a);
	}
	
	for (int i=0; i<3; i++) {
		int a; cin >> a;
		v2.push_back(a);
	}
	
	sort(v1.begin(),v1.end());
	sort(v2.begin(),v2.end());
	
	if (v1[0]*v1[0] + v1[1]*v1[1] == v1[2]*v1[2] && v2[0]*v2[0] +v2[1]*v2[1] == v2[2]*v2[2] && v1 == v2) {
		cout << "YES";
	} else {
		cout << "NO";
	}
	cout << endl;
	
	return 0;
}
