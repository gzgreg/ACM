//team 562, D2UBC^
#include <bits/stdc++.h>

using namespace std;

#define endl '\n'

typedef long long ll;

int p[300005];
int memo[300005];

bool mycomp(const tuple<int,int,int> &t1, const tuple<int,int,int> &t2) {
	return (get<0>(t1)+get<2>(t1)) < (get<0>(t2)+get<2>(t2));
}

tuple<int,int,int> v[300005];

ll dp(int j) {
	if (j < 0) return 0;
	if (memo[j] != -1) {
		return memo[j];
	}
	memo[j] = max(get<1>(v[j])+dp(p[j]),dp(j-1));
	return memo[j];
}

int main () {

	//ios::sync_with_stdio(0);

	int n;
	scanf("%d",&n);
	for (int i=0; i<n; i++) {
		int m,f,w; 
		//cin >> m >> f >> w;
		scanf("%d%d%d",&m,&f,&w);
		v[i] = make_tuple(m,f,w);
	}
	sort(v,v+n,mycomp);
	//reverse(v.begin(),v.end());
	
	memset(memo,-1,sizeof(memo));
	memset(p,-1,sizeof(p));
	
	for (int i=1; i<n; i++) {
		int beg = get<0>(v[i]);
		int ans = -1;
		int start = i-1;
		if (get<0>(v[i-1]) > get<0>(v[i])) start = p[i-1];
		for (int j=start; j>=0; j--) {
			if (get<0>(v[j])+get<2>(v[j]) <= beg) {
				ans = j;
				break;
			}
		}
		p[i] = ans;
	}
	
	//ll ans1 = dp(n);
	
	cout << dp(n-1) << endl;
	return 0;
}
